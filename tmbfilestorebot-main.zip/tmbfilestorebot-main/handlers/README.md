

# Bots new Version

### Special Thanks @AbirHasan2005

# Added With Batch Mode and Ban/Unban Command
